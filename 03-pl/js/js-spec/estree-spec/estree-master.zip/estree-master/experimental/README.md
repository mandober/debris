These documents specify extensions to the core ESTree AST types to support ES
proposals that are in [stages 0, 1 & 2](https://github.com/tc39/proposals).

**NOTE:** These documents may change at anytime and **should not** be seen as
stable.
